<div class="flex space-x-5 items-center">
  {{$slot}}
  <div class="text-left">
  <h1 class="text-xl">{{$count}}</h1>
  <span class="text-gray-500 text-sm">{{$title}}</span>
  </div>
</div>