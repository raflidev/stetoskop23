<div class="bg-orange-600 w-full">
    <div class="flex justify-center items-center">
        <div class="font-medium text-white text-lg">Powered by</div>
        <img src="/images/icon/telkom.png" alt="">
    </div>
</div>
