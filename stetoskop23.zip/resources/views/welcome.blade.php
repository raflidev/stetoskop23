@extends('layout.app')

@section('content')
  <h1 class="text-3xl font-bold underline bg-red-100">
    Hello world! asd
  </h1>
@endsection
