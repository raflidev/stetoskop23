<div class="flex space-x-5 items-center">
  <?php echo e($slot); ?>

  <div class="text-left">
  <h1 class="text-xl"><?php echo e($count); ?></h1>
  <span class="text-gray-500 text-sm"><?php echo e($title); ?></span>
  </div>
</div><?php /**PATH D:\Apicta\stetoskop23\resources\views/components/item-card-grid.blade.php ENDPATH**/ ?>