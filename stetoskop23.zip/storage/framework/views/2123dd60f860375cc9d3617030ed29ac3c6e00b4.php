<a href="<?php echo e(route($route)); ?>" class="rounded-sm <?php echo e(request()->is($href) ? 'bg-orange-400 text-white' : 'text-orange-100'); ?>  px-5 py-2  font-medium flex space-x-3 items-center">
  <div>
    <?php echo e($slot); ?>

  </div>
  <span><?php echo e($title); ?></span>
</a><?php /**PATH D:\Apicta\stetoskop23\resources\views/components/button-link.blade.php ENDPATH**/ ?>