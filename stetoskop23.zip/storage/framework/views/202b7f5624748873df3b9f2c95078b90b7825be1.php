

<?php $__env->startSection('content'); ?>
    
    <div class="min-h-screen flex flex-col">
        <div class="flex">
            <div class="w-8/12 bg-orange-500/80">
                <div class="w-full h-screen flex items-center justify-center">
                    <a href="/" class="rounded-sm">
                        <img src="/images/image-login.png" class="" alt="">
                    </a>
                </div>
            </div>
            <div class="w-4/12">
                <div class="w-full h-screen flex items-center justify-center">
                    <div class="w-9/12 text-gray-700">
                        <h1 class="font-medium text-xl">VAMIC Patient Registration 😊</h1>
                        <p class="text-sm">Please sign up your account</p>
                        <form method="POST" action="<?php echo e(route('register.action')); ?>" class="space-y-3">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label for="nama_lengkap" class="block text-sm text-gray-700">Full Name</label>
                                <input type="text" value="<?php echo e(old('nama_lengkap')); ?>" class="border py-1 px-2 border-gray-200 outline-1 focus:outline-orange-500/70 duration-500 rounded-sm shadow-sm block mt-1 w-full" id="nama_lengkap" name="nama_lengkap">
                            </div>
                            <div>
                                <label for="alamat" class="block text-sm text-gray-700">Address</label>
                                <input type="text" value="<?php echo e(old('alamat')); ?>" class="border py-1 px-2 border-gray-200 outline-1 focus:outline-orange-500/70 duration-500 rounded-sm shadow-sm block mt-1 w-full" id="alamat" name="alamat">
                            </div>
                            <div>
                                <label for="gender" class="block text-sm text-gray-700">Gender</label>
                                <select id="gender" name="gender" value="<?php echo e(old('gender')); ?>" class="border py-1 px-2 border-gray-200 outline-1 focus:outline-orange-500/70 duration-500 rounded-sm shadow-sm block mt-1 w-full">
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div>
                                <label for="email" class="block text-sm text-gray-700">Email</label>
                                <input type="email" value="<?php echo e(old('email')); ?>" class="border py-1 px-2 border-gray-200 outline-1 focus:outline-orange-500/70 duration-500 rounded-sm shadow-sm block mt-1 w-full" id="email" name="email">
                            </div>
                            <div>
                                <label for="password" class="block text-sm text-gray-700">Password</label>
                                <input type="password" class="border py-1 px-2 border-gray-200 outline-1 focus:outline-orange-500/70 duration-500 rounded-sm shadow-sm block mt-1 w-full" id="password" name="password">
                            </div>
                            <div>
                                <label for="password" class="block text-sm text-gray-700">Confirm Password</label>
                                <input type="password" class="border py-1 px-2 border-gray-200 outline-1 focus:outline-orange-500/70 duration-500 rounded-sm shadow-sm block mt-1 w-full" id="password" name="confirm_password">
                            </div>

                            <div class="block mt-4 text-sm">
                                <div>If you are Doctor, <a href="<?php echo e(route('register_dokter')); ?>" class="text-ms text-orange-500">sign up here</a></div>
                            </div>
    
                            <div class="flex items-center justify-center mt-4">
                                <button  class="w-full rounded-sm bg-orange-500 text-white font-medium py-2" type="submit">
                                    Register
                                </button>
                            </div>
    
                            <div class="block mt-4 text-center text-sm">
                                <div>Already Registered? <a href="<?php echo e(route('login')); ?>" class="text-ms text-orange-500">Sign in here</a></div>
                            </div>
                        </form>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apicta\stetoskop23\resources\views/register.blade.php ENDPATH**/ ?>