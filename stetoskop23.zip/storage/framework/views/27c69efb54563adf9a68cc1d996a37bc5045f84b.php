<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<div class="min-h-screen bg-gray-100 pt-10">
    <div class="py-3">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="px-6 py-3 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="mt-4">
                    <p>Doctor or Nurse : <?php echo e($data->nama_dokter); ?></p>
                </div>
                <div class="mt-4">
                    <p>Filename : <?php echo e($data->suara); ?></p>
                    <p class="hidden">path : <span id="path"><?php echo e($data->file_path); ?></span></p>
                </div>
            </div>
        </div>
    </div>

    <div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="px-6 py-3 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <h3 class="text-center">PCG Monitoring</h3>
                <div id='myDiv'>
                    <!-- Plotly chart will be drawn inside this DIV -->
                </div>
                <div class="links">
                    <button type="button" name="playbtn" onclick="wavesurfer.play()">Play</button>
                    <button type="button" name="playbtn" onclick="wavesurfer.pause()">Pause</button>
                    <span id="currentDuration">00:00</span> / <span id="duration"></span>
                </div>
            </div>
        </div>
    </div>

    <div class="py-3">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="px-6 py-3 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <!-- <div class="ostat">
                    <h3 class="">Overall Status</h3>
                    <?php echo csrf_field(); ?>
                    <p>AS : <?php echo e($as); ?></p>
                    <p>MR : <?php echo e($mr); ?></p>
                    <p>MS : <?php echo e($ms); ?></p>
                    <p>MVP : <?php echo e($mvp); ?></p>
                    <p>N : <?php echo e($n); ?></p>
                </div> -->
                <div class="currstat">
                    <h3 class="">Current Status</h3>
                    <?php echo csrf_field(); ?>
                    <p>AS : <?php echo e($as); ?></p>
                    <p>MR : <?php echo e($mr); ?></p>
                    <p>MS : <?php echo e($ms); ?></p>
                    <p>MVP : <?php echo e($mvp); ?></p>
                    <p>N : <?php echo e($n); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var wavesurfer;
    wavesurfer = WaveSurfer.create({
        container: "#myDiv",
        waveColor: 'rgb(200, 0, 200)',
        progressColor: 'rgb(100, 0, 100)',
    })

    // Load the audio file here.
    var load = "/"+document.getElementById('path').textContent
    wavesurfer.load(load);
    wavesurfer.on('ready', function () {
            let time = wavesurfer.getDuration();
            // dom js vanilla
            document.getElementById("duration").innerHTML = formateTime(time);
        });
        wavesurfer.on('audioprocess', function () {
            let time = wavesurfer.getCurrentTime();
            // $("#currentDuration").text(formateTime(time));
            document.getElementById("currentDuration").innerHTML = formateTime(time);
        });

        function formateTime(time) {
            var minutes = Math.floor(time / 60).toFixed(0);
            minutes = (minutes < 10)?"0"+minutes:minutes;
            var seconds = (time - minutes * 60).toFixed(0);
            seconds = (seconds < 10)?"0"+seconds:seconds;
            return minutes.substr(-2) + ":" + seconds;
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apicta\stetoskop23\resources\views/result.blade.php ENDPATH**/ ?>