


<?php $__env->startSection('content'); ?>



<div class="flex">
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
  <div class="w-2/12"></div>
  <div class="w-10/12 bg-gray-100 min-h-screen">
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
      <div class="flex justify-center">
      <div class="w-5/6 bg-white mt-10 shadow rounded-sm py-5 px-8">
          <div class="flex justify-between text-gray-700 items-center">
              <div>
              <div class="text-lg">Welcome, <span class="font-medium">Rafli Ramadhan</span></div>
              <div class="text-sm">You are logged in as patient</div>
              </div>
              <div class="shadow-md p-2 rounded-full outline outline-2 group hover:outline-orange-600 duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8 group-hover:text-orange-600 duration-200">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>              
              </div>
          </div>
          </div>
      </div>

      <div class="flex justify-center">
          <div class="w-5/6 bg-white mt-5 shadow rounded-sm py-5 px-8 text-gray-700">
            <div class="flex space-x-4 items-center mb-6">
                <a href="<?php echo e(route('prediksi.check_index')); ?>" class="outline outline-1 p-1 outline-gray-700 rounded-full inline-block duration-300 group hover:outline-orange-600">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 group-hover:text-orange-600 duration-300">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
                  </svg>            
                </a>
                <h1 class="text-lg">Diagnose</h1>
            </div>

            <div>
              <div class="py-3">
                <p class="hidden">path : <span id="path"><?php echo e($data->file_path); ?></span></p>
                <h3 class="text-center">PCG Monitoring</h3>
                <div id='myDiv'>
                    <!-- Plotly chart will be drawn inside this DIV -->
                </div>
                <div class="links text-sm">
                    <button type="button" name="playbtn" onclick="wavesurfer.play()">Play</button>
                    <button type="button" name="playbtn" onclick="wavesurfer.pause()">Pause</button>
                    <span id="currentDuration">00:00</span> / <span id="duration"></span>
                </div>
              </div>
            </div>

            <form method="POST" action="<?php echo e(route('prediksi.update', ['id' => $id])); ?>" class="mt-10 space-y-4">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div>
                <h2 class="text-sm text-gray-600 mb-1">Doctor name</h2>
                <span><?php echo e($data->nama_dokter); ?></span>
              </div>
              <div>
                <h2 class="text-sm text-gray-600 mb-1">Note</h2>
                <?php if(Auth::user()->role == 'dokter'): ?>
                  <textarea type="text" name="note" class="w-full border border-black rounded-sm p-1" rows="5"><?php echo e($data->note); ?></textarea>
                <?php else: ?>
                  <?php if($data->note == null): ?>
                    <span>-</span>
                  <?php else: ?>
                    <span><?php echo e($data->note); ?></span>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
              <div class="flex space-x-20 text-sm">
                <div>
                  <h2 class="text-sm text-gray-600 mb-2">Diagnose</h2>
                  
                  <?php if(Auth::user()->role == 'dokter'): ?>
                    <select name="diagnose" id="" class="border border-gray-500 w-full rounded-sm px-3 py-2">
                      <option value="<?php echo e($data->result); ?>" selected>
                        <?php if($data->result == 0): ?>
                        Aortic Stenosis
                        <?php elseif($data->result == 1): ?>
                        Mitral Regurgitation
                        <?php elseif($data->result == 2): ?>
                        Mitral Stenosis
                        <?php elseif($data->result == 3): ?>
                        Mitral Valve Prolapse
                        <?php else: ?>
                        Normal
                        <?php endif; ?></option>
                      <option value="0">Aortic Stenosis</option>
                      <option value="1">Mitral Regurgitation</option>
                      <option value="2">Mitral Stenosis</option>
                      <option value="3">Mitral Valve Prolapse</option>
                      <option value="4">Normal</option>
                    </select>
                  <?php else: ?>
                    <?php if($n == true): ?>
                      <span class="px-3 py-1 bg-green-500 text-white rounded-md">Normal</span>
                    <?php elseif($as == true): ?>
                      <span class="px-3 py-1 bg-red-500 text-white rounded-md">Aortic Stenosis</span>
                    <?php elseif($mr == true): ?>
                      <span class="px-3 py-1 bg-red-500 text-white rounded-md">Mitral Regurgitation</span>
                    <?php elseif($ms == true): ?>
                      <span class="px-3 py-1 bg-red-500 text-white rounded-md">Mitral Stenosis</span>
                    <?php elseif($mvp == true): ?>
                      <span class="px-3 py-1 bg-red-500 text-white rounded-md">Mitral Valve Prolapse</span>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>
                <div>
                  <h2 class="text-sm text-gray-600 mb-2">Verification</h2>
                  <?php if(Auth::user()->role == 'dokter'): ?>
                    <select name="status" id="" class="border border-gray-500 w-full rounded-sm px-3 py-2">
                      <option value="<?php echo e($data->result); ?>" selected>
                        <?php if($data->status == 0): ?>
                        Not verified
                        <?php elseif($data->status == 1): ?>
                        Verified
                        <?php endif; ?></option>
                      <option value="0">Not verified</option>
                      <option value="1">Verified</option>
                    </select>
                  <?php else: ?>
                    <?php if($data->status == 0): ?>
                      <span class="px-3 py-1 bg-yellow-500 text-white rounded-md">Not verified</span>
                    <?php elseif($data->status == 1): ?>
                      <span class="px-3 py-1 bg-green-500 text-white rounded-md">Verified</span>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>

                
              </div>
              <?php if(Auth::user()->role == 'dokter'): ?>
                <button class="bg-orange-500 text-white rounded-sm px-3 py-1" type="submit">Save</button>
              <?php else: ?>
                <div>
                  <h2 class="text-sm text-gray-600 mb-1">Updated</h2>
                  <span class="text-lg"><?php echo e($data->updated_at); ?></span>
                </div>
              <?php endif; ?>

            </form>


      </div>

  </div>
</div>

<script>
    var wavesurfer;
    wavesurfer = WaveSurfer.create({
        container: "#myDiv",
        waveColor: 'rgb(200, 0, 200)',
        progressColor: 'rgb(100, 0, 100)',
    })

    // Load the audio file here.
    var load = "/"+document.getElementById('path').textContent
    wavesurfer.load(load);
    wavesurfer.on('ready', function () {
            let time = wavesurfer.getDuration();
            // dom js vanilla
            document.getElementById("duration").innerHTML = formateTime(time);
        });
        wavesurfer.on('audioprocess', function () {
            let time = wavesurfer.getCurrentTime();
            // $("#currentDuration").text(formateTime(time));
            document.getElementById("currentDuration").innerHTML = formateTime(time);
        });

        function formateTime(time) {
            var minutes = Math.floor(time / 60).toFixed(0);
            minutes = (minutes < 10)?"0"+minutes:minutes;
            var seconds = (time - minutes * 60).toFixed(0);
            seconds = (seconds < 10)?"0"+seconds:seconds;
            return minutes.substr(-2) + ":" + seconds;
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apicta\stetoskop23\resources\views/result.blade.php ENDPATH**/ ?>