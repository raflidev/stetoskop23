<?php $__env->startSection('content'); ?>
  <h1 class="text-3xl font-bold underline bg-red-100">
    Hello world! asd
  </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apicta\stetoskop23\resources\views/welcome.blade.php ENDPATH**/ ?>