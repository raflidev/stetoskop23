<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <script src="https://unpkg.com/wavesurfer.js@2.2.1/dist/wavesurfer.min.js"></script>
  <link rel="stylesheet" href="<?php echo e(URL::asset('build/assets/app.89ec1456.css')); ?>">
  <title>Stetoskop Digital</title>
</head>
<body class="font-sans">
    <?php echo $__env->yieldContent('content'); ?>
</body>
<script src="<?php echo e(URL::asset('build/assets/app.f40b63e3.js')); ?>"></script>
</html>

<?php /**PATH D:\Apicta\stetoskop23\resources\views/layout/app.blade.php ENDPATH**/ ?>