<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="min-h-screen bg-gray-100 pt-10">
        <div>
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="px-6 py-3 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                    <h3 class="text-center">Classification</h3>
                    <form action="<?php echo e(route('prediksi.run')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="pl-28">
                            <?php if(Auth::user()->role == 'dokter'): ?>
                            <div>
                                    <label class="block font-medium text-sm text-gray-700" for="id">
                                        pasien
                                    </label>
                                    <select name="user_id" id="id" class="p-4 border mr-0 text-black-800 border-blue-200 bg-white sm:rounded-lg">
                                        <option value=""> -- Select Pasien --</option>
                                        <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama_lengkap); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php endif; ?>
                            <div>
                                <label class="block font-medium text-sm text-gray-700" for="file">
                                    Upload Signal Data
                                </label>
                                <input id="file" class="p-4 border mr-0  text-black-800 border-blue-200 bg-white sm:rounded-lg" type="file" :value="old('file')" name="file">
                            </div>
                            <button class="px-5 sm:rounded-lg bg-yellow-400 text-black-800 font-bold p-4 uppercase border-t border-b border-r" type="submit">
                                Upload
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apicta\stetoskop23\resources\views/klasifikasi.blade.php ENDPATH**/ ?>